function popup(currentLink) {
window.open(currentLink,'Logos','width=600,resizable=yes,scrollbars=yes,height=550');
}