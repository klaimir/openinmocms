<?php
/* 
 * phpMyVisites : website statistics and audience measurements
 * Copyright (C) 2002 - 2006
 * http://www.phpmyvisites.net/ 
 * phpMyVisites is free software (license GNU/GPL)
 * Authors : phpMyVisites team
*/

// $Id: ispCountryList.php 32 2006-08-19 15:14:45Z matthieu_ $


	$GLOBALS['ispCountryList'] = array(
	"uiowa.edu" => "us",
	"rima-tde.net" => "es",
	"fuse.net" => "us",
	"dslextreme.com" => "us",
	"ukrtel.net" => "ua",
	"charter.com" => "us",
	"qwest.net" => "us",
	"bbtec.net" => "jp",
	"fastres.net" => "it",
	"t-dialin.net" => "de",
	"hotchilli.net" => "uk",
	"eth.net" => "in",
	"telus.net" => "ca",
	"gaoland.net" => "fr",
	"telecomplus.net" => "mu",
	"xo.net" => "us",
	"virgin.net" => "uk",
	"cox.net" => "us",
	"ntl.com" => "uk",
	"proxad.net" => "fr",
	"megaquebec.net" => "ca",
);
?>