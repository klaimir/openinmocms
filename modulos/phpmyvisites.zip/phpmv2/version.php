<?php
/* 
 * phpMyVisites : website statistics and audience measurements
 * Copyright (C) 2002 - 2006
 * http://www.phpmyvisites.net/ 
 * phpMyVisites is free software (license GNU/GPL)
 * Authors : phpMyVisites team
*/

// $Id: version.php 238 2009-12-16 19:48:15Z matthieu_ $

define('PHPMV_VERSION', '2.4');
?>