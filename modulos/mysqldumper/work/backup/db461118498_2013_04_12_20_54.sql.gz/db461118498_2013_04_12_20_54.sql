-- Status:49:132:MP_0:db461118498:php:1.24.4:prueba:5.0.51b-community-nt-log:1:::latin1:EXTINFO
--
-- TABLE-INFO
-- TABLE|clientes|1|2172|2013-04-12 20:54:52|MyISAM
-- TABLE|clientes_inmuebles|2|2066|2013-04-12 20:54:52|MyISAM
-- TABLE|ficheros_inmueble|1|2088|2013-04-12 20:54:52|MyISAM
-- TABLE|fotos_inmuebles|2|2104|2013-04-12 20:54:52|MyISAM
-- TABLE|historicos_usuario|15|2504|2013-04-12 20:54:52|MyISAM
-- TABLE|inmuebles|5|3660|2013-04-12 20:54:52|MyISAM
-- TABLE|municipios|5|2152|2013-03-15 13:30:22|MyISAM
-- TABLE|noticias|4|3228|2013-04-11 18:53:58|MyISAM
-- TABLE|opciones|2|2088|2013-03-15 13:28:10|MyISAM
-- TABLE|opciones_inmuebles|1|2057|2013-04-12 20:54:52|MyISAM
-- TABLE|phpmv_a_category|0|1024|2013-04-12 08:11:52|MyISAM
-- TABLE|phpmv_a_config|0|1024|2013-04-12 08:11:52|MyISAM
-- TABLE|phpmv_a_file|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_a_keyword|0|1024|2013-04-12 08:11:52|MyISAM
-- TABLE|phpmv_a_newsletter|0|1024|2013-04-12 08:11:52|MyISAM
-- TABLE|phpmv_a_page|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_a_partner_name|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_a_partner_url|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_a_provider|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_a_resolution|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_a_search_engine|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_a_site|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_a_vars_name|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_a_vars_value|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_archives|7|4460|2013-04-12 20:54:53|MyISAM
-- TABLE|phpmv_category|9|2440|2013-04-12 08:16:37|MyISAM
-- TABLE|phpmv_groups|2|2088|2013-04-12 08:12:01|MyISAM
-- TABLE|phpmv_ip_ignore|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_link_vp|28|3660|2013-04-12 14:26:25|MyISAM
-- TABLE|phpmv_link_vpv|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_newsletter|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_page|14|3496|2013-04-12 08:19:07|MyISAM
-- TABLE|phpmv_page_md5url|1|4141|2013-04-12 14:26:25|MyISAM
-- TABLE|phpmv_page_url|1|2112|2013-04-12 14:26:25|MyISAM
-- TABLE|phpmv_pdf_config|0|1024|2013-04-12 08:11:54|MyISAM
-- TABLE|phpmv_pdf_site_user|0|1024|2013-04-12 08:11:54|MyISAM
-- TABLE|phpmv_plugin_version|0|1024|2013-04-12 08:11:54|MyISAM
-- TABLE|phpmv_query_log|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_site|1|2096|2013-04-12 08:13:57|MyISAM
-- TABLE|phpmv_site_partner|0|1024|2013-04-12 08:11:53|MyISAM
-- TABLE|phpmv_site_partner_url|0|1024|2013-04-12 08:11:54|MyISAM
-- TABLE|phpmv_site_url|1|3116|2013-04-12 08:13:57|MyISAM
-- TABLE|phpmv_users|1|2116|2013-04-12 08:12:01|MyISAM
-- TABLE|phpmv_users_link_groups|0|1024|2013-04-12 08:11:54|MyISAM
-- TABLE|phpmv_vars|0|1024|2013-04-12 08:11:54|MyISAM
-- TABLE|phpmv_version|1|1044|2013-04-12 08:12:01|MyISAM
-- TABLE|phpmv_visit|1|5376|2013-04-12 14:26:25|MyISAM
-- TABLE|usuarios|2|2292|2013-04-12 20:54:53|MyISAM
-- TABLE|zonas_municipios|25|2720|2013-04-11 00:41:01|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'latin1' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2013-04-12 20:54

--
-- Create Table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) collate latin1_spanish_ci NOT NULL,
  `apellidos` varchar(150) collate latin1_spanish_ci NOT NULL,
  `direccion` varchar(200) collate latin1_spanish_ci default NULL,
  `telefono` varchar(9) collate latin1_spanish_ci default NULL,
  `nif` varchar(11) collate latin1_spanish_ci default NULL,
  `observaciones` text collate latin1_spanish_ci,
  `fecha_alta` date NOT NULL,
  `correo` varchar(250) collate latin1_spanish_ci default NULL,
  `busca_vender` tinyint(4) NOT NULL default '0',
  `busca_comprar` tinyint(4) NOT NULL default '0',
  `busca_alquilar` tinyint(4) NOT NULL default '0',
  `busca_alquiler` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id_cliente`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `clientes`
--

/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` (`id_cliente`,`nombre`,`apellidos`,`direccion`,`telefono`,`nif`,`observaciones`,`fecha_alta`,`correo`,`busca_vender`,`busca_comprar`,`busca_alquilar`,`busca_alquiler`) VALUES ('1','�ngel Luis','Berasuain Ruiz','Pablo Ruiz Picasso, 4','956078391','75777802R','Tiene que pensarlo','2013-04-03','klaimir@hotmail.com','1','1','0','0');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;


--
-- Create Table `clientes_inmuebles`
--

DROP TABLE IF EXISTS `clientes_inmuebles`;
CREATE TABLE `clientes_inmuebles` (
  `cliente` int(11) NOT NULL,
  `inmueble` int(11) NOT NULL,
  PRIMARY KEY  (`cliente`,`inmueble`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `clientes_inmuebles`
--

/*!40000 ALTER TABLE `clientes_inmuebles` DISABLE KEYS */;
INSERT INTO `clientes_inmuebles` (`cliente`,`inmueble`) VALUES ('1','6');
INSERT INTO `clientes_inmuebles` (`cliente`,`inmueble`) VALUES ('1','7');
/*!40000 ALTER TABLE `clientes_inmuebles` ENABLE KEYS */;


--
-- Create Table `ficheros_inmueble`
--

DROP TABLE IF EXISTS `ficheros_inmueble`;
CREATE TABLE `ficheros_inmueble` (
  `id_fichero` int(11) NOT NULL,
  `inmueble` int(11) NOT NULL,
  `texto_fichero` text collate latin1_spanish_ci,
  `fichero` varchar(255) collate latin1_spanish_ci NOT NULL,
  PRIMARY KEY  (`id_fichero`,`inmueble`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `ficheros_inmueble`
--

/*!40000 ALTER TABLE `ficheros_inmueble` DISABLE KEYS */;
INSERT INTO `ficheros_inmueble` (`id_fichero`,`inmueble`,`texto_fichero`,`fichero`) VALUES ('1','6','Fichero 1','cocinero.jpg');
/*!40000 ALTER TABLE `ficheros_inmueble` ENABLE KEYS */;


--
-- Create Table `fotos_inmuebles`
--

DROP TABLE IF EXISTS `fotos_inmuebles`;
CREATE TABLE `fotos_inmuebles` (
  `id_foto` int(2) NOT NULL,
  `inmueble` int(2) NOT NULL,
  `nombre_foto` varchar(200) collate latin1_spanish_ci NOT NULL,
  PRIMARY KEY  (`id_foto`,`inmueble`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `fotos_inmuebles`
--

/*!40000 ALTER TABLE `fotos_inmuebles` DISABLE KEYS */;
INSERT INTO `fotos_inmuebles` (`id_foto`,`inmueble`,`nombre_foto`) VALUES ('2','4','cocinero.jpg');
INSERT INTO `fotos_inmuebles` (`id_foto`,`inmueble`,`nombre_foto`) VALUES ('3','4','buscador.png');
/*!40000 ALTER TABLE `fotos_inmuebles` ENABLE KEYS */;


--
-- Create Table `historicos_usuario`
--

DROP TABLE IF EXISTS `historicos_usuario`;
CREATE TABLE `historicos_usuario` (
  `id_historico` int(11) NOT NULL,
  `usuario` int(11) NOT NULL,
  `accion` longtext collate latin1_spanish_ci NOT NULL,
  `fecha_hora` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id_historico`,`usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `historicos_usuario`
--

/*!40000 ALTER TABLE `historicos_usuario` DISABLE KEYS */;
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('2','1','Conectar','2013-03-27 22:35:43');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('1','1','Conectar','2013-03-26 17:57:52');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('1','2','Deshabilitar cuenta usuario','2013-03-31 23:47:17');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('2','2','Habilitar cuenta usuario','2013-03-31 23:48:02');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('4','1','Conectar','2013-03-31 23:05:01');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('3','1','Conectar','2013-03-28 19:59:57');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('5','1','Conectar','2013-04-01 23:57:23');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('3','2','Conectar','2013-04-01 14:25:59');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('6','1','Conectar','2013-04-03 21:55:16');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('7','1','Conectar','2013-04-04 15:05:22');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('8','1','Conectar','2013-04-05 23:55:06');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('9','1','Conectar','2013-04-08 14:23:54');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('10','1','Conectar','2013-04-09 22:53:08');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('11','1','Conectar','2013-04-11 14:18:22');
INSERT INTO `historicos_usuario` (`id_historico`,`usuario`,`accion`,`fecha_hora`) VALUES ('12','1','Conectar','2013-04-12 08:15:23');
/*!40000 ALTER TABLE `historicos_usuario` ENABLE KEYS */;


--
-- Create Table `inmuebles`
--

DROP TABLE IF EXISTS `inmuebles`;
CREATE TABLE `inmuebles` (
  `id_inmueble` int(11) NOT NULL auto_increment,
  `metros` int(4) NOT NULL,
  `precio` double NOT NULL,
  `zona` int(2) default NULL,
  `municipio` int(2) NOT NULL,
  `observaciones` text collate latin1_spanish_ci,
  `direccion` varchar(200) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`id_inmueble`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `inmuebles`
--

/*!40000 ALTER TABLE `inmuebles` DISABLE KEYS */;
INSERT INTO `inmuebles` (`id_inmueble`,`metros`,`precio`,`zona`,`municipio`,`observaciones`,`direccion`) VALUES ('3','75','250',NULL,'5',NULL,'Sirenas, C�diz');
INSERT INTO `inmuebles` (`id_inmueble`,`metros`,`precio`,`zona`,`municipio`,`observaciones`,`direccion`) VALUES ('4','70','122000','4','4','Se vende preciosa vivienda de tres dormitorios, sal�n comedor, cocina independiente, un ba�o completos, suelos de terrazo, ventanas de aluminio blanco, puertas de ucola, muy luminoso, edificio con unos 15 a�os aproximadamente de antiguedad, en muy buen estado, se encuentra cerca de colegios, de comercios, de mercado, de parada de autob�s, muy cerca de la Avenida Juan Carlos I, cerca de la Avenida de la Bah�a y del Centro Comercial El Corte Ingles, precio negociable, mejor ver.\r\n-------------------**********************-------------------',NULL);
INSERT INTO `inmuebles` (`id_inmueble`,`metros`,`precio`,`zona`,`municipio`,`observaciones`,`direccion`) VALUES ('6','70','100000','3','1','As� mismo los firmantes quedan informados y consienten que sus datos puedan ser utilizados por Axon Comunicaci�n para la contrataci�n o aplicaci�n a otros productos y servicios de la Entidad, as� como para el env�o de ofertas comerciales de cualesquiera bienes, productos o servicios, que comercialice o financie esta Entidad y que puedan ser de su inter�s. Este env�o podr� efectuarse por cualquier medio (correspondencia, tel�fono, fax, correo electr�nico o cualquier otro medio telem�tico). Los derechos de acceso, rectificaci�n, cancelaci�n y oposici�n podr�n ser ejercidos por el interesado, en los t�rminos indicados en la referida normativa, dirigi�ndose por escrito al Departamento de C/Dulcinea, 42, 4� B, 28020 Madrid, o en la direcci�n de correo electr�nico Ax�n Comunicaci�n, as� como tambi�n para la revocaci�n de las autorizaciones concedidas.','Pablo Ruiz Picasso 4');
INSERT INTO `inmuebles` (`id_inmueble`,`metros`,`precio`,`zona`,`municipio`,`observaciones`,`direccion`) VALUES ('7','100','200000','1','2','Bonito','Cayetano Rold�n, 1');
INSERT INTO `inmuebles` (`id_inmueble`,`metros`,`precio`,`zona`,`municipio`,`observaciones`,`direccion`) VALUES ('9','120','300000',NULL,'3',NULL,NULL);
/*!40000 ALTER TABLE `inmuebles` ENABLE KEYS */;


--
-- Create Table `municipios`
--

DROP TABLE IF EXISTS `municipios`;
CREATE TABLE `municipios` (
  `id_municipio` int(2) NOT NULL,
  `nombre_municipio` varchar(200) collate latin1_spanish_ci NOT NULL,
  PRIMARY KEY  (`id_municipio`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `municipios`
--

/*!40000 ALTER TABLE `municipios` DISABLE KEYS */;
INSERT INTO `municipios` (`id_municipio`,`nombre_municipio`) VALUES ('1','C�diz');
INSERT INTO `municipios` (`id_municipio`,`nombre_municipio`) VALUES ('2','San Fernando');
INSERT INTO `municipios` (`id_municipio`,`nombre_municipio`) VALUES ('3','Puerto Real');
INSERT INTO `municipios` (`id_municipio`,`nombre_municipio`) VALUES ('4','Chiclana');
INSERT INTO `municipios` (`id_municipio`,`nombre_municipio`) VALUES ('5','Otros');
/*!40000 ALTER TABLE `municipios` ENABLE KEYS */;


--
-- Create Table `noticias`
--

DROP TABLE IF EXISTS `noticias`;
CREATE TABLE `noticias` (
  `id_noticia` int(11) NOT NULL auto_increment,
  `titulo` varchar(200) collate latin1_spanish_ci NOT NULL,
  `descripcion` text collate latin1_spanish_ci,
  `enlace` varchar(200) collate latin1_spanish_ci default NULL,
  `tiempo` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `publicar` tinyint(4) default '0',
  PRIMARY KEY  (`id_noticia`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `noticias`
--

/*!40000 ALTER TABLE `noticias` DISABLE KEYS */;
INSERT INTO `noticias` (`id_noticia`,`titulo`,`descripcion`,`enlace`,`tiempo`,`publicar`) VALUES ('2','Previa Barcelona-PSG','El Barcelona realiz� una suave sesi�n de entrenamiento previa al partido entre el Bar�a y el PSG con la mirada puesta en Leo Messi. Dependiendo de los resultados de la ecograf�a a la que ha sido sometido esta ma�ana y de sus sensaciones horas antes del partido, entre los m�dicos, los fisios y el jugador decidir�n si juega o no.','http://www.marca.com','2013-04-11 07:47:05','0');
INSERT INTO `noticias` (`id_noticia`,`titulo`,`descripcion`,`enlace`,`tiempo`,`publicar`) VALUES ('3','asdasdsad','asdasda',NULL,'2013-04-11 01:26:14','0');
INSERT INTO `noticias` (`id_noticia`,`titulo`,`descripcion`,`enlace`,`tiempo`,`publicar`) VALUES ('4','El esp�ritu de Messi','Un destello de Messi salv� al Bar�a de la eliminaci�n ante el PSG en el Camp Nou. Los franceses se adelantaron en el marcador en el minuto 49 gracias a un gol de Pastore y la presencia del argentino en el campo se hizo necesaria. Entr� en el 62\' y en el 70\' gener� la jugada del empate. Meti� un gran pase para Villa, que la dej� atr�s para que Pedro tirase.','http://www.elmundodeportivo.com/','2013-04-11 18:46:34','1');
INSERT INTO `noticias` (`id_noticia`,`titulo`,`descripcion`,`enlace`,`tiempo`,`publicar`) VALUES ('5','CONSCIENTE DEL PAPEL CLAVE DEL ARGENTINO EN EL EQUIPO','Jordi Roura analiz� el partido ante el PSG: \"No sabremos nunca si sin Messi habr�amos pasado, es una suposici�n, pero todos se han dejado la piel en el campo. Era un partido muy complicado, muy dif�cil. El PSG es un grand�simo equipo\".','http://www.marca.com/','2013-04-11 18:46:16','1');
/*!40000 ALTER TABLE `noticias` ENABLE KEYS */;


--
-- Create Table `opciones`
--

DROP TABLE IF EXISTS `opciones`;
CREATE TABLE `opciones` (
  `id_opcion` int(2) NOT NULL,
  `nombre_opcion` varchar(100) collate latin1_spanish_ci NOT NULL,
  PRIMARY KEY  (`id_opcion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `opciones`
--

/*!40000 ALTER TABLE `opciones` DISABLE KEYS */;
INSERT INTO `opciones` (`id_opcion`,`nombre_opcion`) VALUES ('1','Comprar');
INSERT INTO `opciones` (`id_opcion`,`nombre_opcion`) VALUES ('2','Alquilar');
/*!40000 ALTER TABLE `opciones` ENABLE KEYS */;


--
-- Create Table `opciones_inmuebles`
--

DROP TABLE IF EXISTS `opciones_inmuebles`;
CREATE TABLE `opciones_inmuebles` (
  `opcion` int(2) NOT NULL,
  `inmueble` int(11) NOT NULL,
  PRIMARY KEY  (`opcion`,`inmueble`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `opciones_inmuebles`
--

/*!40000 ALTER TABLE `opciones_inmuebles` DISABLE KEYS */;
INSERT INTO `opciones_inmuebles` (`opcion`,`inmueble`) VALUES ('1','6');
/*!40000 ALTER TABLE `opciones_inmuebles` ENABLE KEYS */;


--
-- Create Table `phpmv_a_category`
--

DROP TABLE IF EXISTS `phpmv_a_category`;
CREATE TABLE `phpmv_a_category` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_category`
--

/*!40000 ALTER TABLE `phpmv_a_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_category` ENABLE KEYS */;


--
-- Create Table `phpmv_a_config`
--

DROP TABLE IF EXISTS `phpmv_a_config`;
CREATE TABLE `phpmv_a_config` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_config`
--

/*!40000 ALTER TABLE `phpmv_a_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_config` ENABLE KEYS */;


--
-- Create Table `phpmv_a_file`
--

DROP TABLE IF EXISTS `phpmv_a_file`;
CREATE TABLE `phpmv_a_file` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` text collate latin1_spanish_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_file`
--

/*!40000 ALTER TABLE `phpmv_a_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_file` ENABLE KEYS */;


--
-- Create Table `phpmv_a_keyword`
--

DROP TABLE IF EXISTS `phpmv_a_keyword`;
CREATE TABLE `phpmv_a_keyword` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` text collate latin1_spanish_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_keyword`
--

/*!40000 ALTER TABLE `phpmv_a_keyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_keyword` ENABLE KEYS */;


--
-- Create Table `phpmv_a_newsletter`
--

DROP TABLE IF EXISTS `phpmv_a_newsletter`;
CREATE TABLE `phpmv_a_newsletter` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(60) collate latin1_spanish_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_newsletter`
--

/*!40000 ALTER TABLE `phpmv_a_newsletter` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_newsletter` ENABLE KEYS */;


--
-- Create Table `phpmv_a_page`
--

DROP TABLE IF EXISTS `phpmv_a_page`;
CREATE TABLE `phpmv_a_page` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` text collate latin1_spanish_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_page`
--

/*!40000 ALTER TABLE `phpmv_a_page` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_page` ENABLE KEYS */;


--
-- Create Table `phpmv_a_partner_name`
--

DROP TABLE IF EXISTS `phpmv_a_partner_name`;
CREATE TABLE `phpmv_a_partner_name` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_partner_name`
--

/*!40000 ALTER TABLE `phpmv_a_partner_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_partner_name` ENABLE KEYS */;


--
-- Create Table `phpmv_a_partner_url`
--

DROP TABLE IF EXISTS `phpmv_a_partner_url`;
CREATE TABLE `phpmv_a_partner_url` (
  `id` int(11) NOT NULL auto_increment,
  `name` text collate latin1_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_partner_url`
--

/*!40000 ALTER TABLE `phpmv_a_partner_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_partner_url` ENABLE KEYS */;


--
-- Create Table `phpmv_a_provider`
--

DROP TABLE IF EXISTS `phpmv_a_provider`;
CREATE TABLE `phpmv_a_provider` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_provider`
--

/*!40000 ALTER TABLE `phpmv_a_provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_provider` ENABLE KEYS */;


--
-- Create Table `phpmv_a_resolution`
--

DROP TABLE IF EXISTS `phpmv_a_resolution`;
CREATE TABLE `phpmv_a_resolution` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(20) collate latin1_spanish_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_resolution`
--

/*!40000 ALTER TABLE `phpmv_a_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_resolution` ENABLE KEYS */;


--
-- Create Table `phpmv_a_search_engine`
--

DROP TABLE IF EXISTS `phpmv_a_search_engine`;
CREATE TABLE `phpmv_a_search_engine` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_search_engine`
--

/*!40000 ALTER TABLE `phpmv_a_search_engine` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_search_engine` ENABLE KEYS */;


--
-- Create Table `phpmv_a_site`
--

DROP TABLE IF EXISTS `phpmv_a_site`;
CREATE TABLE `phpmv_a_site` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` text collate latin1_spanish_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_site`
--

/*!40000 ALTER TABLE `phpmv_a_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_site` ENABLE KEYS */;


--
-- Create Table `phpmv_a_vars_name`
--

DROP TABLE IF EXISTS `phpmv_a_vars_name`;
CREATE TABLE `phpmv_a_vars_name` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate latin1_spanish_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_vars_name`
--

/*!40000 ALTER TABLE `phpmv_a_vars_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_vars_name` ENABLE KEYS */;


--
-- Create Table `phpmv_a_vars_value`
--

DROP TABLE IF EXISTS `phpmv_a_vars_value`;
CREATE TABLE `phpmv_a_vars_value` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate latin1_spanish_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_a_vars_value`
--

/*!40000 ALTER TABLE `phpmv_a_vars_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_a_vars_value` ENABLE KEYS */;


--
-- Create Table `phpmv_archives`
--

DROP TABLE IF EXISTS `phpmv_archives`;
CREATE TABLE `phpmv_archives` (
  `idarchives` int(10) unsigned NOT NULL auto_increment,
  `idsite` int(10) unsigned NOT NULL default '0',
  `done` tinyint(4) NOT NULL default '0',
  `period` tinyint(1) NOT NULL default '0',
  `simple` tinyint(4) NOT NULL default '0',
  `date1` varchar(10) collate latin1_spanish_ci NOT NULL default '00:00:00',
  `date2` varchar(10) collate latin1_spanish_ci NOT NULL default '00:00:00',
  `nb_uniq_vis` mediumint(8) unsigned NOT NULL default '0',
  `nb_vis` mediumint(8) unsigned NOT NULL default '0',
  `nb_vis_returning` int(8) NOT NULL default '0',
  `nb_uniq_vis_returning` int(11) NOT NULL default '0',
  `nb_pag` mediumint(8) unsigned NOT NULL default '0',
  `nb_pag_returning` int(8) NOT NULL default '0',
  `nb_uniq_pag` smallint(5) unsigned NOT NULL default '0',
  `nb_max_pag` smallint(5) unsigned NOT NULL default '0',
  `nb_vis_1pag` mediumint(8) unsigned NOT NULL default '0',
  `nb_vis_1pag_returning` mediumint(8) NOT NULL default '0',
  `sum_vis_lth` int(10) unsigned NOT NULL default '0',
  `sum_vis_lth_returning` int(10) NOT NULL default '0',
  `nb_direct` mediumint(8) unsigned NOT NULL default '0',
  `nb_search_engine` mediumint(8) unsigned NOT NULL default '0',
  `nb_site` mediumint(8) unsigned NOT NULL default '0',
  `nb_newsletter` mediumint(8) unsigned NOT NULL default '0',
  `nb_partner` mediumint(8) unsigned NOT NULL default '0',
  `vis_period` longblob,
  `vis_nb_vis` blob,
  `vis_st` blob,
  `vis_lt` blob,
  `pag_st` blob,
  `pag_lt` blob,
  `vis_lth` blob,
  `vis_nb_pag` blob,
  `vis_pag_grp` longblob,
  `vis_country` blob,
  `vis_continent` blob,
  `vis_provider` longblob,
  `vis_config` longblob,
  `vis_os` blob,
  `vis_browser` blob,
  `vis_browser_type` blob,
  `vis_resolution` longblob,
  `vis_plugin` blob,
  `vis_search_engine` longblob,
  `vis_keyword` longblob,
  `vis_site` longblob,
  `vis_partner` longblob,
  `vis_newsletter` longblob,
  `int_lt` blob,
  `int_st` blob,
  `int_referer_type` longblob,
  `int_search_engine` longblob,
  `int_keyword` longblob,
  `int_site` longblob,
  `int_partner` longblob,
  `int_newsletter` longblob,
  `int_country` longblob,
  `int_continent` longblob,
  `int_config` longblob,
  `int_os` longblob,
  `int_browser` longblob,
  `int_resolution` longblob,
  `compressed` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`idarchives`),
  KEY `pmvindex1` (`idsite`),
  KEY `pmvindex2` (`done`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_archives`
--

/*!40000 ALTER TABLE `phpmv_archives` DISABLE KEYS */;
INSERT INTO `phpmv_archives` (`idarchives`,`idsite`,`done`,`period`,`simple`,`date1`,`date2`,`nb_uniq_vis`,`nb_vis`,`nb_vis_returning`,`nb_uniq_vis_returning`,`nb_pag`,`nb_pag_returning`,`nb_uniq_pag`,`nb_max_pag`,`nb_vis_1pag`,`nb_vis_1pag_returning`,`sum_vis_lth`,`sum_vis_lth_returning`,`nb_direct`,`nb_search_engine`,`nb_site`,`nb_newsletter`,`nb_partner`,`vis_period`,`vis_nb_vis`,`vis_st`,`vis_lt`,`pag_st`,`pag_lt`,`vis_lth`,`vis_nb_pag`,`vis_pag_grp`,`vis_country`,`vis_continent`,`vis_provider`,`vis_config`,`vis_os`,`vis_browser`,`vis_browser_type`,`vis_resolution`,`vis_plugin`,`vis_search_engine`,`vis_keyword`,`vis_site`,`vis_partner`,`vis_newsletter`,`int_lt`,`int_st`,`int_referer_type`,`int_search_engine`,`int_keyword`,`int_site`,`int_partner`,`int_newsletter`,`int_country`,`int_continent`,`int_config`,`int_os`,`int_browser`,`int_resolution`,`compressed`) VALUES ('1','1','2','1','0','2013-04-12','1365747283','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1');
INSERT INTO `phpmv_archives` (`idarchives`,`idsite`,`done`,`period`,`simple`,`date1`,`date2`,`nb_uniq_vis`,`nb_vis`,`nb_vis_returning`,`nb_uniq_vis_returning`,`nb_pag`,`nb_pag_returning`,`nb_uniq_pag`,`nb_max_pag`,`nb_vis_1pag`,`nb_vis_1pag_returning`,`sum_vis_lth`,`sum_vis_lth_returning`,`nb_direct`,`nb_search_engine`,`nb_site`,`nb_newsletter`,`nb_partner`,`vis_period`,`vis_nb_vis`,`vis_st`,`vis_lt`,`pag_st`,`pag_lt`,`vis_lth`,`vis_nb_pag`,`vis_pag_grp`,`vis_country`,`vis_continent`,`vis_provider`,`vis_config`,`vis_os`,`vis_browser`,`vis_browser_type`,`vis_resolution`,`vis_plugin`,`vis_search_engine`,`vis_keyword`,`vis_site`,`vis_partner`,`vis_newsletter`,`int_lt`,`int_st`,`int_referer_type`,`int_search_engine`,`int_keyword`,`int_site`,`int_partner`,`int_newsletter`,`int_country`,`int_continent`,`int_config`,`int_os`,`int_browser`,`int_resolution`,`compressed`) VALUES ('2','1','2','1','0','2013-04-12','1365747318','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1');
INSERT INTO `phpmv_archives` (`idarchives`,`idsite`,`done`,`period`,`simple`,`date1`,`date2`,`nb_uniq_vis`,`nb_vis`,`nb_vis_returning`,`nb_uniq_vis_returning`,`nb_pag`,`nb_pag_returning`,`nb_uniq_pag`,`nb_max_pag`,`nb_vis_1pag`,`nb_vis_1pag_returning`,`sum_vis_lth`,`sum_vis_lth_returning`,`nb_direct`,`nb_search_engine`,`nb_site`,`nb_newsletter`,`nb_partner`,`vis_period`,`vis_nb_vis`,`vis_st`,`vis_lt`,`pag_st`,`pag_lt`,`vis_lth`,`vis_nb_pag`,`vis_pag_grp`,`vis_country`,`vis_continent`,`vis_provider`,`vis_config`,`vis_os`,`vis_browser`,`vis_browser_type`,`vis_resolution`,`vis_plugin`,`vis_search_engine`,`vis_keyword`,`vis_site`,`vis_partner`,`vis_newsletter`,`int_lt`,`int_st`,`int_referer_type`,`int_search_engine`,`int_keyword`,`int_site`,`int_partner`,`int_newsletter`,`int_country`,`int_continent`,`int_config`,`int_os`,`int_browser`,`int_resolution`,`compressed`) VALUES ('3','1','2','1','0','2013-04-12','1365747367','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1');
INSERT INTO `phpmv_archives` (`idarchives`,`idsite`,`done`,`period`,`simple`,`date1`,`date2`,`nb_uniq_vis`,`nb_vis`,`nb_vis_returning`,`nb_uniq_vis_returning`,`nb_pag`,`nb_pag_returning`,`nb_uniq_pag`,`nb_max_pag`,`nb_vis_1pag`,`nb_vis_1pag_returning`,`sum_vis_lth`,`sum_vis_lth_returning`,`nb_direct`,`nb_search_engine`,`nb_site`,`nb_newsletter`,`nb_partner`,`vis_period`,`vis_nb_vis`,`vis_st`,`vis_lt`,`pag_st`,`pag_lt`,`vis_lth`,`vis_nb_pag`,`vis_pag_grp`,`vis_country`,`vis_continent`,`vis_provider`,`vis_config`,`vis_os`,`vis_browser`,`vis_browser_type`,`vis_resolution`,`vis_plugin`,`vis_search_engine`,`vis_keyword`,`vis_site`,`vis_partner`,`vis_newsletter`,`int_lt`,`int_st`,`int_referer_type`,`int_search_engine`,`int_keyword`,`int_site`,`int_partner`,`int_newsletter`,`int_country`,`int_continent`,`int_config`,`int_os`,`int_browser`,`int_resolution`,`compressed`) VALUES ('4','1','2','1','0','2013-04-12','1365747450','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1');
INSERT INTO `phpmv_archives` (`idarchives`,`idsite`,`done`,`period`,`simple`,`date1`,`date2`,`nb_uniq_vis`,`nb_vis`,`nb_vis_returning`,`nb_uniq_vis_returning`,`nb_pag`,`nb_pag_returning`,`nb_uniq_pag`,`nb_max_pag`,`nb_vis_1pag`,`nb_vis_1pag_returning`,`sum_vis_lth`,`sum_vis_lth_returning`,`nb_direct`,`nb_search_engine`,`nb_site`,`nb_newsletter`,`nb_partner`,`vis_period`,`vis_nb_vis`,`vis_st`,`vis_lt`,`pag_st`,`pag_lt`,`vis_lth`,`vis_nb_pag`,`vis_pag_grp`,`vis_country`,`vis_continent`,`vis_provider`,`vis_config`,`vis_os`,`vis_browser`,`vis_browser_type`,`vis_resolution`,`vis_plugin`,`vis_search_engine`,`vis_keyword`,`vis_site`,`vis_partner`,`vis_newsletter`,`int_lt`,`int_st`,`int_referer_type`,`int_search_engine`,`int_keyword`,`int_site`,`int_partner`,`int_newsletter`,`int_country`,`int_continent`,`int_config`,`int_os`,`int_browser`,`int_resolution`,`compressed`) VALUES ('5','1','2','1','0','2013-04-12','1365747486','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1');
INSERT INTO `phpmv_archives` (`idarchives`,`idsite`,`done`,`period`,`simple`,`date1`,`date2`,`nb_uniq_vis`,`nb_vis`,`nb_vis_returning`,`nb_uniq_vis_returning`,`nb_pag`,`nb_pag_returning`,`nb_uniq_pag`,`nb_max_pag`,`nb_vis_1pag`,`nb_vis_1pag_returning`,`sum_vis_lth`,`sum_vis_lth_returning`,`nb_direct`,`nb_search_engine`,`nb_site`,`nb_newsletter`,`nb_partner`,`vis_period`,`vis_nb_vis`,`vis_st`,`vis_lt`,`pag_st`,`pag_lt`,`vis_lth`,`vis_nb_pag`,`vis_pag_grp`,`vis_country`,`vis_continent`,`vis_provider`,`vis_config`,`vis_os`,`vis_browser`,`vis_browser_type`,`vis_resolution`,`vis_plugin`,`vis_search_engine`,`vis_keyword`,`vis_site`,`vis_partner`,`vis_newsletter`,`int_lt`,`int_st`,`int_referer_type`,`int_search_engine`,`int_keyword`,`int_site`,`int_partner`,`int_newsletter`,`int_country`,`int_continent`,`int_config`,`int_os`,`int_browser`,`int_resolution`,`compressed`) VALUES ('6','1','2','1','0','2013-04-12','1365747583','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1');
INSERT INTO `phpmv_archives` (`idarchives`,`idsite`,`done`,`period`,`simple`,`date1`,`date2`,`nb_uniq_vis`,`nb_vis`,`nb_vis_returning`,`nb_uniq_vis_returning`,`nb_pag`,`nb_pag_returning`,`nb_uniq_pag`,`nb_max_pag`,`nb_vis_1pag`,`nb_vis_1pag_returning`,`sum_vis_lth`,`sum_vis_lth_returning`,`nb_direct`,`nb_search_engine`,`nb_site`,`nb_newsletter`,`nb_partner`,`vis_period`,`vis_nb_vis`,`vis_st`,`vis_lt`,`pag_st`,`pag_lt`,`vis_lth`,`vis_nb_pag`,`vis_pag_grp`,`vis_country`,`vis_continent`,`vis_provider`,`vis_config`,`vis_os`,`vis_browser`,`vis_browser_type`,`vis_resolution`,`vis_plugin`,`vis_search_engine`,`vis_keyword`,`vis_site`,`vis_partner`,`vis_newsletter`,`int_lt`,`int_st`,`int_referer_type`,`int_search_engine`,`int_keyword`,`int_site`,`int_partner`,`int_newsletter`,`int_country`,`int_continent`,`int_config`,`int_os`,`int_browser`,`int_resolution`,`compressed`) VALUES ('7','1','2','1','0','2013-04-12','1365747662','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1');
/*!40000 ALTER TABLE `phpmv_archives` ENABLE KEYS */;


--
-- Create Table `phpmv_category`
--

DROP TABLE IF EXISTS `phpmv_category`;
CREATE TABLE `phpmv_category` (
  `idcategory` int(10) unsigned NOT NULL auto_increment,
  `complete_name` varchar(255) collate latin1_spanish_ci NOT NULL default '',
  `name` varchar(100) collate latin1_spanish_ci default NULL,
  `level` smallint(5) unsigned NOT NULL default '0',
  `idparent` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`idcategory`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_category`
--

/*!40000 ALTER TABLE `phpmv_category` DISABLE KEYS */;
INSERT INTO `phpmv_category` (`idcategory`,`complete_name`,`name`,`level`,`idparent`) VALUES ('1','gesticadiz','gesticadiz','1','0');
INSERT INTO `phpmv_category` (`idcategory`,`complete_name`,`name`,`level`,`idparent`) VALUES ('2','gesticadiz/app','app','2','1');
INSERT INTO `phpmv_category` (`idcategory`,`complete_name`,`name`,`level`,`idparent`) VALUES ('3','gesticadiz/app/noticias','noticias','3','2');
INSERT INTO `phpmv_category` (`idcategory`,`complete_name`,`name`,`level`,`idparent`) VALUES ('4','gesticadiz/app/buscador','buscador','3','2');
INSERT INTO `phpmv_category` (`idcategory`,`complete_name`,`name`,`level`,`idparent`) VALUES ('5','gesticadiz/app/login','login','3','2');
INSERT INTO `phpmv_category` (`idcategory`,`complete_name`,`name`,`level`,`idparent`) VALUES ('6','gesticadiz/app/acceso','acceso','3','2');
INSERT INTO `phpmv_category` (`idcategory`,`complete_name`,`name`,`level`,`idparent`) VALUES ('7','gesticadiz/app/inmuebles','inmuebles','3','2');
INSERT INTO `phpmv_category` (`idcategory`,`complete_name`,`name`,`level`,`idparent`) VALUES ('8','gesticadiz/app/clientes','clientes','3','2');
INSERT INTO `phpmv_category` (`idcategory`,`complete_name`,`name`,`level`,`idparent`) VALUES ('9','gesticadiz/app/usuarios','usuarios','3','2');
/*!40000 ALTER TABLE `phpmv_category` ENABLE KEYS */;


--
-- Create Table `phpmv_groups`
--

DROP TABLE IF EXISTS `phpmv_groups`;
CREATE TABLE `phpmv_groups` (
  `idgroups` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(40) collate latin1_spanish_ci default NULL,
  `view` tinyint(1) unsigned default '0',
  `admin` tinyint(3) unsigned default '0',
  PRIMARY KEY  (`idgroups`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_groups`
--

/*!40000 ALTER TABLE `phpmv_groups` DISABLE KEYS */;
INSERT INTO `phpmv_groups` (`idgroups`,`name`,`view`,`admin`) VALUES ('1','admin','1','1');
INSERT INTO `phpmv_groups` (`idgroups`,`name`,`view`,`admin`) VALUES ('2','view','1','0');
/*!40000 ALTER TABLE `phpmv_groups` ENABLE KEYS */;


--
-- Create Table `phpmv_ip_ignore`
--

DROP TABLE IF EXISTS `phpmv_ip_ignore`;
CREATE TABLE `phpmv_ip_ignore` (
  `idip_ignore` int(10) unsigned NOT NULL auto_increment,
  `idsite` int(10) unsigned NOT NULL default '0',
  `ip_min` bigint(11) default NULL,
  `ip_max` bigint(11) default NULL,
  PRIMARY KEY  (`idip_ignore`),
  KEY `pmvindex` (`idsite`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_ip_ignore`
--

/*!40000 ALTER TABLE `phpmv_ip_ignore` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_ip_ignore` ENABLE KEYS */;


--
-- Create Table `phpmv_link_vp`
--

DROP TABLE IF EXISTS `phpmv_link_vp`;
CREATE TABLE `phpmv_link_vp` (
  `idlink_vp` int(11) NOT NULL auto_increment,
  `idvisit` int(10) unsigned NOT NULL default '0',
  `idpage` int(10) unsigned NOT NULL default '0',
  `idpage_ref` int(11) unsigned NOT NULL default '0',
  `total_time_page_ref` int(10) unsigned default NULL,
  PRIMARY KEY  (`idlink_vp`),
  KEY `pmvindex` (`idvisit`,`idpage`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_link_vp`
--

/*!40000 ALTER TABLE `phpmv_link_vp` DISABLE KEYS */;
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('1','9','1','16','758');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('2','9','2','1','3');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('3','9','3','2','1');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('4','9','4','3','53');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('5','9','5','4','5');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('6','9','6','5','2');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('7','9','7','6','1');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('8','9','6','7','6');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('9','9','6','6','60');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('10','9','8','6','3');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('11','9','9','8','1');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('12','9','6','9','2');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('13','9','10','6','2');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('14','9','11','10','3');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('15','9','9','11','2');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('16','9','12','9','126');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('17','9','4','12','3');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('18','9','2','4','4');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('19','9','13','2','4');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('20','9','2','13','2');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('21','9','14','2','1');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('22','9','2','14','1');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('23','9','1','2','3');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('24','9','1','1','74');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('25','9','2','1','3');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('26','9','3','2','2');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('27','9','4','3','276');
INSERT INTO `phpmv_link_vp` (`idlink_vp`,`idvisit`,`idpage`,`idpage_ref`,`total_time_page_ref`) VALUES ('28','1','2','4','1800');
/*!40000 ALTER TABLE `phpmv_link_vp` ENABLE KEYS */;


--
-- Create Table `phpmv_link_vpv`
--

DROP TABLE IF EXISTS `phpmv_link_vpv`;
CREATE TABLE `phpmv_link_vpv` (
  `idlink_vp` int(11) NOT NULL default '0',
  `idvars` int(11) NOT NULL default '0',
  PRIMARY KEY  (`idlink_vp`,`idvars`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_link_vpv`
--

/*!40000 ALTER TABLE `phpmv_link_vpv` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_link_vpv` ENABLE KEYS */;


--
-- Create Table `phpmv_newsletter`
--

DROP TABLE IF EXISTS `phpmv_newsletter`;
CREATE TABLE `phpmv_newsletter` (
  `idnewsletter` int(10) unsigned NOT NULL auto_increment,
  `idsite` int(10) unsigned NOT NULL default '0',
  `name` varchar(90) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`idnewsletter`),
  KEY `pmvindex` (`idsite`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_newsletter`
--

/*!40000 ALTER TABLE `phpmv_newsletter` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_newsletter` ENABLE KEYS */;


--
-- Create Table `phpmv_page`
--

DROP TABLE IF EXISTS `phpmv_page`;
CREATE TABLE `phpmv_page` (
  `idpage` int(10) unsigned NOT NULL auto_increment,
  `idcategory` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`idpage`),
  KEY `pmvindex` (`idcategory`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_page`
--

/*!40000 ALTER TABLE `phpmv_page` DISABLE KEYS */;
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('1','3','rss.php');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('2','4','index.php');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('3','4','ver_datos_adicionales.phpid=3');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('4','5','index.php');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('5','6','index.php');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('6','7','index.php');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('7','7','editar.phpid=3');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('8','8','index.php');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('9','9','index.php');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('10','3','index.php');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('11','3','editar.phpid=5');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('12','5','desconectar.phpdoLogout=true');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('13','4','ver_datos_adicionales.phpid=6');
INSERT INTO `phpmv_page` (`idpage`,`idcategory`,`name`) VALUES ('14','4','ver_datos_adicionales.phpid=9');
/*!40000 ALTER TABLE `phpmv_page` ENABLE KEYS */;


--
-- Create Table `phpmv_page_md5url`
--

DROP TABLE IF EXISTS `phpmv_page_md5url`;
CREATE TABLE `phpmv_page_md5url` (
  `idpage_md5url` int(10) unsigned NOT NULL auto_increment,
  `idpage` int(10) unsigned NOT NULL default '0',
  `md5url` char(32) collate latin1_spanish_ci default NULL,
  `idpage_url` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`idpage_md5url`),
  KEY `idpage` (`idpage`),
  KEY `url` (`md5url`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_page_md5url`
--

/*!40000 ALTER TABLE `phpmv_page_md5url` DISABLE KEYS */;
INSERT INTO `phpmv_page_md5url` (`idpage_md5url`,`idpage`,`md5url`,`idpage_url`) VALUES ('1','2','bba67fe6592ed0f7232525e4458ee7c7','1');
/*!40000 ALTER TABLE `phpmv_page_md5url` ENABLE KEYS */;


--
-- Create Table `phpmv_page_url`
--

DROP TABLE IF EXISTS `phpmv_page_url`;
CREATE TABLE `phpmv_page_url` (
  `idpage_url` int(10) unsigned NOT NULL auto_increment,
  `url` text collate latin1_spanish_ci,
  PRIMARY KEY  (`idpage_url`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_page_url`
--

/*!40000 ALTER TABLE `phpmv_page_url` DISABLE KEYS */;
INSERT INTO `phpmv_page_url` (`idpage_url`,`url`) VALUES ('1','http://localhost/gesticadiz/app/buscador/index.php');
/*!40000 ALTER TABLE `phpmv_page_url` ENABLE KEYS */;


--
-- Create Table `phpmv_pdf_config`
--

DROP TABLE IF EXISTS `phpmv_pdf_config`;
CREATE TABLE `phpmv_pdf_config` (
  `idpdf` int(10) unsigned NOT NULL auto_increment,
  `name_pdf` varchar(90) collate latin1_spanish_ci default NULL,
  `params_pdf` longblob,
  PRIMARY KEY  (`idpdf`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_pdf_config`
--

/*!40000 ALTER TABLE `phpmv_pdf_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_pdf_config` ENABLE KEYS */;


--
-- Create Table `phpmv_pdf_site_user`
--

DROP TABLE IF EXISTS `phpmv_pdf_site_user`;
CREATE TABLE `phpmv_pdf_site_user` (
  `idsite` int(10) unsigned NOT NULL default '0',
  `login` varchar(20) collate latin1_spanish_ci NOT NULL default '0',
  `idpdf` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`idsite`,`login`,`idpdf`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_pdf_site_user`
--

/*!40000 ALTER TABLE `phpmv_pdf_site_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_pdf_site_user` ENABLE KEYS */;


--
-- Create Table `phpmv_plugin_version`
--

DROP TABLE IF EXISTS `phpmv_plugin_version`;
CREATE TABLE `phpmv_plugin_version` (
  `code` varchar(255) collate latin1_spanish_ci NOT NULL,
  `version` varchar(255) collate latin1_spanish_ci NOT NULL,
  PRIMARY KEY  (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_plugin_version`
--

/*!40000 ALTER TABLE `phpmv_plugin_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_plugin_version` ENABLE KEYS */;


--
-- Create Table `phpmv_query_log`
--

DROP TABLE IF EXISTS `phpmv_query_log`;
CREATE TABLE `phpmv_query_log` (
  `idquery_log` int(11) NOT NULL auto_increment,
  `idsite` int(11) NOT NULL default '0',
  `query` smallint(6) NOT NULL default '0',
  `time` float NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `daytime` time NOT NULL default '00:00:00',
  PRIMARY KEY  (`idquery_log`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_query_log`
--

/*!40000 ALTER TABLE `phpmv_query_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_query_log` ENABLE KEYS */;


--
-- Create Table `phpmv_site`
--

DROP TABLE IF EXISTS `phpmv_site`;
CREATE TABLE `phpmv_site` (
  `idsite` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(90) collate latin1_spanish_ci default NULL,
  `logo` varchar(15) collate latin1_spanish_ci default NULL,
  `params_choice` varchar(6) collate latin1_spanish_ci NOT NULL default 'all',
  `params_names` varchar(255) collate latin1_spanish_ci NOT NULL default '',
  `idpdf` int(10) NOT NULL default '-1',
  `path_theme` varchar(255) collate latin1_spanish_ci NOT NULL default 'default',
  PRIMARY KEY  (`idsite`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_site`
--

/*!40000 ALTER TABLE `phpmv_site` DISABLE KEYS */;
INSERT INTO `phpmv_site` (`idsite`,`name`,`logo`,`params_choice`,`params_names`,`idpdf`,`path_theme`) VALUES ('1','Gesticadiz','pixel.gif','all','','-1','default');
/*!40000 ALTER TABLE `phpmv_site` ENABLE KEYS */;


--
-- Create Table `phpmv_site_partner`
--

DROP TABLE IF EXISTS `phpmv_site_partner`;
CREATE TABLE `phpmv_site_partner` (
  `idsite_partner` int(10) unsigned NOT NULL auto_increment,
  `idsite` int(10) unsigned NOT NULL default '0',
  `name` varchar(90) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`idsite_partner`),
  KEY `pmvindex` (`idsite`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_site_partner`
--

/*!40000 ALTER TABLE `phpmv_site_partner` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_site_partner` ENABLE KEYS */;


--
-- Create Table `phpmv_site_partner_url`
--

DROP TABLE IF EXISTS `phpmv_site_partner_url`;
CREATE TABLE `phpmv_site_partner_url` (
  `idsite_partner_url` int(10) unsigned NOT NULL auto_increment,
  `idsite_partner` int(10) unsigned NOT NULL default '0',
  `url` varchar(200) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`idsite_partner_url`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_site_partner_url`
--

/*!40000 ALTER TABLE `phpmv_site_partner_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_site_partner_url` ENABLE KEYS */;


--
-- Create Table `phpmv_site_url`
--

DROP TABLE IF EXISTS `phpmv_site_url`;
CREATE TABLE `phpmv_site_url` (
  `idsite_url` int(10) unsigned NOT NULL auto_increment,
  `idsite` int(10) unsigned NOT NULL default '0',
  `url` varchar(255) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`idsite_url`),
  KEY `pmvindex` (`idsite`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_site_url`
--

/*!40000 ALTER TABLE `phpmv_site_url` DISABLE KEYS */;
INSERT INTO `phpmv_site_url` (`idsite_url`,`idsite`,`url`) VALUES ('1','1','http://localhost/gesticadiz');
/*!40000 ALTER TABLE `phpmv_site_url` ENABLE KEYS */;


--
-- Create Table `phpmv_users`
--

DROP TABLE IF EXISTS `phpmv_users`;
CREATE TABLE `phpmv_users` (
  `login` varchar(20) collate latin1_spanish_ci NOT NULL default '',
  `password` varchar(255) collate latin1_spanish_ci default NULL,
  `alias` varchar(45) collate latin1_spanish_ci default NULL,
  `email` varchar(100) collate latin1_spanish_ci NOT NULL default '',
  `send_mail` int(10) default NULL,
  `rss_hash` varchar(100) collate latin1_spanish_ci NOT NULL default '',
  `date_registered` int(11) default NULL,
  PRIMARY KEY  (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_users`
--

/*!40000 ALTER TABLE `phpmv_users` DISABLE KEYS */;
INSERT INTO `phpmv_users` (`login`,`password`,`alias`,`email`,`send_mail`,`rss_hash`,`date_registered`) VALUES ('anonymous',NULL,'Anonymous user','','0','ffffffffffffff493e8d55a4a75de3f90a1',NULL);
/*!40000 ALTER TABLE `phpmv_users` ENABLE KEYS */;


--
-- Create Table `phpmv_users_link_groups`
--

DROP TABLE IF EXISTS `phpmv_users_link_groups`;
CREATE TABLE `phpmv_users_link_groups` (
  `idsite` int(10) unsigned NOT NULL default '0',
  `idgroups` int(10) unsigned NOT NULL default '0',
  `login` varchar(20) collate latin1_spanish_ci NOT NULL default '0',
  PRIMARY KEY  (`idsite`,`idgroups`,`login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_users_link_groups`
--

/*!40000 ALTER TABLE `phpmv_users_link_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_users_link_groups` ENABLE KEYS */;


--
-- Create Table `phpmv_vars`
--

DROP TABLE IF EXISTS `phpmv_vars`;
CREATE TABLE `phpmv_vars` (
  `idvars` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) collate latin1_spanish_ci NOT NULL default '',
  `int_value` int(10) default NULL,
  `varchar_value` varchar(255) collate latin1_spanish_ci default NULL,
  PRIMARY KEY  (`idvars`),
  KEY `pmvindex` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_vars`
--

/*!40000 ALTER TABLE `phpmv_vars` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpmv_vars` ENABLE KEYS */;


--
-- Create Table `phpmv_version`
--

DROP TABLE IF EXISTS `phpmv_version`;
CREATE TABLE `phpmv_version` (
  `version` varchar(255) collate latin1_spanish_ci NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_version`
--

/*!40000 ALTER TABLE `phpmv_version` DISABLE KEYS */;
INSERT INTO `phpmv_version` (`version`) VALUES ('2.4');
/*!40000 ALTER TABLE `phpmv_version` ENABLE KEYS */;


--
-- Create Table `phpmv_visit`
--

DROP TABLE IF EXISTS `phpmv_visit`;
CREATE TABLE `phpmv_visit` (
  `idvisit` int(10) unsigned NOT NULL auto_increment,
  `idsite` int(10) unsigned NOT NULL default '0',
  `idcookie` varchar(32) collate latin1_spanish_ci default NULL,
  `returning` tinyint(1) NOT NULL default '0',
  `last_visit_time` time NOT NULL default '00:00:00',
  `server_date` date default NULL,
  `server_time` time NOT NULL default '00:00:00',
  `referer` text collate latin1_spanish_ci,
  `os` char(3) collate latin1_spanish_ci default NULL,
  `browser_name` varchar(10) collate latin1_spanish_ci NOT NULL default '',
  `browser_version` varchar(20) collate latin1_spanish_ci NOT NULL default '',
  `resolution` varchar(9) collate latin1_spanish_ci default NULL,
  `color_depth` tinyint(2) unsigned default NULL,
  `pdf` tinyint(1) NOT NULL default '0',
  `flash` tinyint(1) NOT NULL default '0',
  `java` tinyint(1) NOT NULL default '0',
  `javascript` tinyint(1) NOT NULL default '0',
  `director` tinyint(1) NOT NULL default '0',
  `quicktime` tinyint(1) NOT NULL default '0',
  `realplayer` tinyint(1) NOT NULL default '0',
  `windowsmedia` tinyint(1) NOT NULL default '0',
  `cookie` tinyint(1) NOT NULL default '0',
  `local_time` time NOT NULL default '00:00:00',
  `ip` int(10) default NULL,
  `hostname_ext` varchar(100) collate latin1_spanish_ci default NULL,
  `browser_lang` varchar(60) collate latin1_spanish_ci default NULL,
  `total_pages` smallint(5) unsigned default NULL,
  `total_time` smallint(5) unsigned default NULL,
  `country` char(3) collate latin1_spanish_ci default NULL,
  `continent` char(3) collate latin1_spanish_ci default NULL,
  `exit_idpage` int(11) NOT NULL default '0',
  `entry_idpage` int(11) NOT NULL default '0',
  `entry_idpageurl` int(11) NOT NULL default '0',
  `md5config` varchar(32) collate latin1_spanish_ci NOT NULL default '',
  PRIMARY KEY  (`idvisit`),
  KEY `idsite` (`idsite`),
  KEY `server_date` (`server_date`),
  KEY `md5config` (`md5config`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `phpmv_visit`
--

/*!40000 ALTER TABLE `phpmv_visit` DISABLE KEYS */;
INSERT INTO `phpmv_visit` (`idvisit`,`idsite`,`idcookie`,`returning`,`last_visit_time`,`server_date`,`server_time`,`referer`,`os`,`browser_name`,`browser_version`,`resolution`,`color_depth`,`pdf`,`flash`,`java`,`javascript`,`director`,`quicktime`,`realplayer`,`windowsmedia`,`cookie`,`local_time`,`ip`,`hostname_ext`,`browser_lang`,`total_pages`,`total_time`,`country`,`continent`,`exit_idpage`,`entry_idpage`,`entry_idpageurl`,`md5config`) VALUES ('1','1','af881f4b73f36ab43cf8069fafcd4817','1','14:26:24','2013-04-12','14:26:24','http://localhost/gesticadiz/app/buscador/ver_datos_adicionales.php?id=3','WNT','SF','537.3','1920x1080','32','1','1','1','1','0','0','0','0','1','14:26:24','2130706433','jobeet.localhost','es-ES,es;q=0.8','1','20','xx','unk','2','2','1','fa0b7b3d5de52147028b7c1066bd4568');
/*!40000 ALTER TABLE `phpmv_visit` ENABLE KEYS */;


--
-- Create Table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL auto_increment,
  `nick` varchar(50) collate latin1_spanish_ci NOT NULL,
  `password` varchar(50) collate latin1_spanish_ci NOT NULL,
  `nombre` varchar(100) collate latin1_spanish_ci NOT NULL,
  `apellidos` varchar(150) collate latin1_spanish_ci NOT NULL,
  `fecha_alta` date NOT NULL,
  `correo` varchar(250) collate latin1_spanish_ci NOT NULL,
  `num_accesos` tinyint(4) NOT NULL default '0',
  `cuenta_activa` tinyint(4) default '1',
  `notif_ult_acceso` tinyint(4) NOT NULL default '0',
  `perfil` varchar(50) collate latin1_spanish_ci NOT NULL,
  PRIMARY KEY  (`id_usuario`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `usuarios`
--

/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`id_usuario`,`nick`,`password`,`nombre`,`apellidos`,`fecha_alta`,`correo`,`num_accesos`,`cuenta_activa`,`notif_ult_acceso`,`perfil`) VALUES ('1','angelbr','631985aa4db977a284a6511093856b8d','�ngel Luis','Berasuain Ruiz','2013-03-26','klaimir@hotmail.com','0','1','0','administrador');
INSERT INTO `usuarios` (`id_usuario`,`nick`,`password`,`nombre`,`apellidos`,`fecha_alta`,`correo`,`num_accesos`,`cuenta_activa`,`notif_ult_acceso`,`perfil`) VALUES ('2','admin','21232f297a57a5a743894a0e4a801fc3','Administrador','Administrador','2013-03-27','meugeniabr@arquitectosdecadiz.com','0','1','0','administrador');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;


--
-- Create Table `zonas_municipios`
--

DROP TABLE IF EXISTS `zonas_municipios`;
CREATE TABLE `zonas_municipios` (
  `id_zona` int(2) NOT NULL,
  `municipio` int(2) NOT NULL,
  `nombre_zona` varchar(200) collate latin1_spanish_ci NOT NULL,
  PRIMARY KEY  (`municipio`,`id_zona`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Data for Table `zonas_municipios`
--

/*!40000 ALTER TABLE `zonas_municipios` DISABLE KEYS */;
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('1','1','Centro');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('2','1','Avenida - San Jos�');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('3','1','Avenida - Estadio');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('4','1','Bah�a Blanca');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('5','1','Barriada Paz');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('6','1','Loreto - Puntales');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('7','1','La Laguna');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('8','1','Playa');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('9','1','Corte Ingl�s');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('1','2','Camposoto');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('2','2','Centro');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('3','2','Caser�a');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('4','2','Iglesia Mayor - Plz. Toros');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('5','2','Estaci�n');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('1','3','R�o San Pedro');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('2','3','Centro');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('3','3','Casines');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('4','3','Marina de la Bah�a');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('5','3','Canteras');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('6','3','Villanueva Golf');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('1','4','El Marquesado');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('2','4','Pinar de los Franceses');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('3','4','La Barrosa');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('4','4','Centro');
INSERT INTO `zonas_municipios` (`id_zona`,`municipio`,`nombre_zona`) VALUES ('5','4','Novo Sancti Petri');
/*!40000 ALTER TABLE `zonas_municipios` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

